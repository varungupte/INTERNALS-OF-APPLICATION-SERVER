import socket         
import os       
s = socket.socket()  
ip_address=raw_input('Please enter the ip_address of the ftp server:-(Default is:- 127.0.0.1)-')
port=int(input('Please enter the port number:-(Default is:- 2019)-'))
username=raw_input('Please enter the username:- (Default is:- test)-')
password=raw_input('Please enter the password:- (Default is:- test)-')
# print ip_address,port,filename           
s.connect((ip_address,port)) 

credentials=username+':'+password
s.send(credentials)
k=s.recv(1024)
if(k=='connection not established.Please check your credentials.'):
	s.close()
	print(k)
else:
	print(k)
	# socket for data transferring
	sdata = socket.socket() 
	portdata=2029
	sdata.connect((ip_address,portdata)) 
	directory=raw_input('Please enter the directory name:-(Default is:- /home/test/)')
	sdata.send(directory)
	k2=sdata.recv(1024)
	if(k2=='directory does not exists.'):
		sdata.close
		print(k2)
	else:
		print(k2)
		filename=raw_input('Please enter the filename (Default is:- test.txt ):-')
		sdata.send(filename)
		fk=sdata.recv(1024)
		if(fk=="File does not exist."):
			print(fk)
			sdata.close()
		else:
			data = ""
			actual_data=""
			with open(filename, 'wb') as f:
				print ('file opened.')
				print('receiving data...')
				while True:
					data = sdata.recv(1024)
					actual_data+=data
					print(data)
					if not data:
						break
					# f.write(data)

			xx=actual_data.split('@')	
			yy=xx[0].split('$')
			datatest=yy[0]
			length=yy[1]
			content_type=xx[1]

			l=str(len(datatest))
			# print(l)
			print('content_type is:- '+content_type)
			print('Done receiving')

			# print(length)

			if l==length :
				print("file not corrupted")
			else:
				print("file corrupted")

			f.close()
sdata.close()
s.close()   