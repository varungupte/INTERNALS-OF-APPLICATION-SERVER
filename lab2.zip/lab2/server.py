import socket
import os		

s = socket.socket()		 
print "Socket successfully created"
port = 2019	
# an empty string means that the server can listen to incoming connections from other computers as well			
s.bind(('127.0.0.1', port))		 
print "socket binded to %s" %(port) 
s.listen(5)	 
print "socket is listening"			

dummy_username="test"
dummy_password="test"
dummy_directory='/home/test/'

while True: 
	c, addr = s.accept()	 
	print 'Got connection request from', addr 
	# c.send('Thank you for connecting') 
	credentials=c.recv(1024)
	k=credentials.split(':')
	username=k[0]
	password=k[1]
	if(username==dummy_username and password==dummy_password):
		c.send('Thank you for connecting') 
	else:
		c.send('connection not established.Please check your credentials.')
		c.close
		continue
	sdata = socket.socket()		 
	portdata = 2029		
	sdata.bind(('127.0.0.1', portdata))		 
	sdata.listen(5)	 
	cdata, addr = sdata.accept()	
	directory=cdata.recv(1024)
	if(directory==dummy_directory):
		cdata.send('directory present')
	else:
		cdata.send('directory does not exists.')
		cdata.close()
		continue
	filename=cdata.recv(1024)
	if os.path.isfile(filename):
		f = open(filename, "rb")
		cdata.send("File Founded.")
		#the actual data
		actual_data=""
		data = f.read(1024)
		while (data):
		   actual_data+=data
		   data =f.read(1024)

	    #appending filesize
		l = str(len(actual_data))
		print(l)
		actual_data+="$"
		actual_data+=l
		# c.send(l)

		#appending content_type
		content_type = "text"
		actual_data+="@"
		# c.send(content_type)
		actual_data+=content_type

		cdata.sendall(actual_data)

		f.close()
		cdata.close()
		c.close() 
	else:

		print("file does exist at this time")
		cdata.send("File does not exist.")
		cdata.close()
		c.close()
		continue
