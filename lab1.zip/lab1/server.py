import socket
import os		
import json
s = socket.socket()		 
print "Socket successfully created"
port = 2019	
# an empty string means that the server can listen to incoming connections from other computers as well			
s.bind(('127.0.0.1', port))		 
print "socket binded to %s" %(port) 
s.listen(5)	 
print "socket is listening"		
d2 = json.load(open("config.txt"))

while True: 
	c, addr = s.accept()	 
	print 'Got connection from', addr 
	c.send('Thank you for connecting') 
	client_input=c.recv(1024)
	url=client_input
	x=url.split(':')
	ip_address=x[0]
	print("The home directory is:- "+d2[ip_address])
	y=x[1].split('/')
	port=y[0]
	z=y[1].split('=')
	filename=z[1]	
	if os.path.isfile(filename):
		f = open(filename, "rb")
		c.send("File Founded.")
		#the actual data
		actual_data=""
		data = f.read(1024)
		while (data):
		   actual_data+=data
		   data =f.read(1024)

	    #appending filesize
		l = str(len(actual_data))
		print(l)
		actual_data+="$"
		actual_data+=l
		# c.send(l)

		#appending content_type
		content_type = "text"
		actual_data+="@"
		# c.send(content_type)
		actual_data+=content_type

		c.sendall(actual_data)

		f.close()
		c.close() 
	else:

		print("file does exist at this time")
		c.send("File does not exist.")
		c.close()
		continue
