import socket         
import os       
s = socket.socket()  
url=raw_input('Please enter the url(format:-GO http://ip_address:port_number/filename=XXXXXX):-(Default is:-GO http://127.0.0.1:2019/filename=test.txt) ')
print url
yyy=url[10:]
x=yyy.split(':')
# print()
ip_address=x[0]
y=x[1].split('/')
port=int(y[0])
z=y[1].split('=')
filename=z[1]
print(ip_address,port)
# print ip_address,port,filename           
s.connect((ip_address,port)) 
print s.recv(1024) 

s.send(yyy)
fk=s.recv(1024)
if(fk=="File does not exist."):
	print(fk)
	s.close()
else:
	print(fk)
	data = ""
	actual_data=""
	with open(filename, 'wb') as f:
		print ('file opened.')
		print('receiving data...')
		while True:
			data = s.recv(1024)
			actual_data+=data
			if not data:
				break
			print data
			# f.write(data)

	xx=actual_data.split('@')	
	yy=xx[0].split('$')
	datatest=yy[0]
	length=yy[1]
	content_type=xx[1]

	l=str(len(datatest))
	# print(l)
	print('content_type is:- '+content_type)
	print('Done receiving')

	# print(length)

	if l==length :
		print("file not corrupted")
	else:
		print("file corrupted")

	f.close()
	s.close()   